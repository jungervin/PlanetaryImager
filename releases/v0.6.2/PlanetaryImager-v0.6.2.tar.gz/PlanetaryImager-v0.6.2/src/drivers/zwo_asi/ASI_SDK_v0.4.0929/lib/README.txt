Applicable platform:
ubuntu:x86, x64
armv6: raspberry pi
armv5: armv5 Soft-Float
mac os: mac
armv7: raspberry pi2
armv8: arm 64bit

$ sudo install asi.rules /lib/udev/rules.d
and reconnect camera, then the camera can be opened without root
