#include "functional.h"

#include "functional.moc"